// RouteFinder.java
package edu.unicda.services;

import edu.unicda.models.Parada;
import edu.unicda.models.Ruta;
import java.util.*;

public class RouteFinder {
    private final Map<Parada, List<Connection>> graph;

    public RouteFinder(List<Ruta> rutas) {
        this.graph = buildGraph(rutas);
    }

    private Map<Parada, List<Connection>> buildGraph(List<Ruta> rutas) {
        Map<Parada, List<Connection>> graph = new HashMap<>();

        for (Ruta ruta : rutas) {
            List<Parada> paradasRuta = ruta.getParadas();
            for (int i = 0; i < paradasRuta.size() - 1; i++) {
                Parada actual = paradasRuta.get(i);
                Parada siguiente = paradasRuta.get(i + 1);
                
                // Crear conexión de ida
                graph.computeIfAbsent(actual, k -> new ArrayList<>())
                    .add(new Connection(siguiente, ruta, calcularPeso(actual, siguiente)));
                
                // Crear conexión de vuelta (asumiendo rutas bidireccionales)
                graph.computeIfAbsent(siguiente, k -> new ArrayList<>())
                    .add(new Connection(actual, ruta, calcularPeso(siguiente, actual)));
            }
        }

        return graph;
    }

    private double calcularPeso(Parada a, Parada b) {
        // Peso basado en distancia y tiempo estimado
        return distanciaEntre(a, b) * 0.1; // Factor de conversión distancia -> tiempo
    }

    private double distanciaEntre(Parada a, Parada b) {
        // Fórmula de Haversine para calcular distancia entre dos puntos geográficos
        final int R = 6371; // Radio de la Tierra en km
        double lat1 = a.getLatitud();
        double lon1 = a.getLongitud();
        double lat2 = b.getLatitud();
        double lon2 = b.getLongitud();

        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double aa = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double cc = 2 * Math.atan2(Math.sqrt(aa), Math.sqrt(1 - aa));
        return R * cc;
    }

    public List<Ruta> encontrarMejorRuta(Parada origen, Parada destino) {
        if (!graph.containsKey(origen) || !graph.containsKey(destino)) {
            return Collections.emptyList();
        }

        // Estructuras para Dijkstra
        Map<Parada, Double> distancias = new HashMap<>();
        Map<Parada, Connection> previas = new HashMap<>();
        PriorityQueue<Parada> cola = new PriorityQueue<>(Comparator.comparingDouble(distancias::get));

        // Inicialización
        for (Parada parada : graph.keySet()) {
            distancias.put(parada, parada.equals(origen) ? 0.0 : Double.POSITIVE_INFINITY);
        }
        cola.add(origen);

        // Algoritmo de Dijkstra
        while (!cola.isEmpty()) {
            Parada actual = cola.poll();
            
            if (actual.equals(destino)) break;
            
            for (Connection conexion : graph.getOrDefault(actual, Collections.emptyList())) {
                Parada vecino = conexion.getParada();
                double nuevaDist = distancias.get(actual) + conexion.getPeso();
                
                if (nuevaDist < distancias.get(vecino)) {
                    distancias.put(vecino, nuevaDist);
                    previas.put(vecino, conexion);
                    cola.remove(vecino); // Actualizar prioridad
                    cola.add(vecino);
                }
            }
        }

        // Reconstruir ruta
        return reconstruirRuta(previas, destino);
    }

    private List<Ruta> reconstruirRuta(Map<Parada, Connection> previas, Parada destino) {
        LinkedList<Ruta> rutaOptima = new LinkedList<>();
        Connection conexion = previas.get(destino);
        
        while (conexion != null) {
            rutaOptima.addFirst(conexion.getRuta());
            conexion = previas.get(conexion.getParada());
        }
        
        return rutaOptima;
    }

    private static class Connection {
        private final Parada parada;
        private final Ruta ruta;
        private final double peso;

        public Connection(Parada parada, Ruta ruta, double peso) {
            this.parada = parada;
            this.ruta = ruta;
            this.peso = peso;
        }

        public Parada getParada() { return parada; }
        public Ruta getRuta() { return ruta; }
        public double getPeso() { return peso; }
    }
}