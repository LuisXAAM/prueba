package edu.unicda.services;

import edu.unicda.models.Parada;
import edu.unicda.models.Ruta;
import java.util.*;
import java.sql.SQLException;

public class RouteFinder {
    private final Map<Parada, List<Connection>> graph;
    private final ParadaDAO paradaDAO;

    public RouteFinder(List<Ruta> rutas, ParadaDAO paradaDAO) throws SQLException {
        this.paradaDAO = Objects.requireNonNull(paradaDAO, "ParadaDAO no puede ser nulo");
        this.graph = buildGraph(Objects.requireNonNull(rutas, "La lista de rutas no puede ser nula"));
    }

    private Map<Parada, List<Connection>> buildGraph(List<Ruta> rutas) throws SQLException {
        Map<Parada, List<Connection>> graph = new HashMap<>();
        
        if (rutas.isEmpty()) {
            throw new IllegalArgumentException("La lista de rutas no puede estar vacía");
        }

        for (Ruta ruta : rutas) {
            List<Parada> paradasRuta = paradaDAO.obtenerParadasPorRuta(ruta.getId());
            
            if (paradasRuta == null || paradasRuta.isEmpty()) {
                System.err.println("Advertencia: Ruta ID " + ruta.getId() + " no tiene paradas asignadas");
                continue;
            }

            // Construir conexiones entre paradas consecutivas
            for (int i = 0; i < paradasRuta.size() - 1; i++) {
                Parada actual = paradasRuta.get(i);
                Parada siguiente = paradasRuta.get(i + 1);
                
                // Validar que las paradas tengan coordenadas válidas
                if (!validarCoordenadas(actual) || !validarCoordenadas(siguiente)) {
                    System.err.println("Advertencia: Parada con coordenadas inválidas en ruta ID " + ruta.getId());
                    continue;
                }

                double peso = calcularPeso(actual, siguiente);
                
                // Conexión de ida
                graph.computeIfAbsent(actual, k -> new ArrayList<>())
                    .add(new Connection(siguiente, ruta, peso));
                
                // Conexión de vuelta (transporte bidireccional)
                graph.computeIfAbsent(siguiente, k -> new ArrayList<>())
                    .add(new Connection(actual, ruta, peso));
            }
        }
        
        if (graph.isEmpty()) {
            throw new IllegalStateException("No se pudo construir el grafo. Verifique que las rutas tengan paradas válidas");
        }
        
        return graph;
    }

    private boolean validarCoordenadas(Parada parada) {
        return parada.getLatitud() != 0 && parada.getLongitud() != 0;
    }

    private double calcularPeso(Parada a, Parada b) {
        // Peso basado en distancia + factor por tipo de transporte
        double distancia = distanciaEntre(a, b);
        String tipoTransporte = a.getTipo(); // Asumimos que todas las paradas de la ruta son del mismo tipo
        
        // Ajustar peso según tipo de transporte
        switch (tipoTransporte.toLowerCase()) {
            case "metro": return distancia * 0.08; // Más rápido
            case "omsa": return distancia * 0.12;  // Intermedio
            case "concho": return distancia * 0.15; // Más lento
            default: return distancia * 0.1;       // Valor por defecto
        }
    }

    private double distanciaEntre(Parada a, Parada b) {
        // Fórmula de Haversine mejorada con validación
        if (a.equals(b)) return 0;
        
        final double R = 6371; // Radio de la Tierra en km
        double lat1 = Math.toRadians(a.getLatitud());
        double lon1 = Math.toRadians(a.getLongitud());
        double lat2 = Math.toRadians(b.getLatitud());
        double lon2 = Math.toRadians(b.getLongitud());

        double dLat = lat2 - lat1;
        double dLon = lon2 - lon1;

        double aa = Math.sin(dLat/2) * Math.sin(dLat/2) +
                   Math.cos(lat1) * Math.cos(lat2) *
                   Math.sin(dLon/2) * Math.sin(dLon/2);
        
        double cc = 2 * Math.atan2(Math.sqrt(aa), Math.sqrt(1-aa));
        return R * cc;
    }

    public List<Ruta> encontrarMejorRuta(Parada origen, Parada destino) {
        // Validación de parámetros
        if (origen == null || destino == null) {
            System.err.println("Error: Paradas de origen/destino no pueden ser nulas");
            return Collections.emptyList();
        }

        if (!graph.containsKey(origen) || !graph.containsKey(destino)) {
            System.err.println("Error: Paradas no encontradas en el grafo");
            return Collections.emptyList();
        }

        // Implementación de Dijkstra mejorada
        Map<Parada, Double> distancias = new HashMap<>();
        Map<Parada, Connection> previas = new HashMap<>();
        PriorityQueue<Parada> cola = new PriorityQueue<>(
            Comparator.comparingDouble(p -> distancias.getOrDefault(p, Double.POSITIVE_INFINITY))
        );

        // Inicialización
        graph.keySet().forEach(p -> distancias.put(p, Double.POSITIVE_INFINITY));
        distancias.put(origen, 0.0);
        cola.add(origen);

        // Procesamiento
        while (!cola.isEmpty()) {
            Parada actual = cola.poll();
            
            if (actual.equals(destino)) break;
            
            for (Connection conexion : graph.getOrDefault(actual, Collections.emptyList())) {
                Parada vecino = conexion.getParada();
                double nuevaDist = distancias.get(actual) + conexion.getPeso();
                
                if (nuevaDist < distancias.get(vecino)) {
                    distancias.put(vecino, nuevaDist);
                    previas.put(vecino, conexion);
                    
                    // Actualizar la prioridad en la cola
                    cola.remove(vecino);
                    cola.add(vecino);
                }
            }
        }

        // Reconstrucción de la ruta con información adicional
        return reconstruirRuta(previas, destino, distancias.getOrDefault(destino, Double.POSITIVE_INFINITY));
    }

    private List<Ruta> reconstruirRuta(Map<Parada, Connection> previas, Parada destino, double distanciaTotal) {
        LinkedList<Ruta> rutaOptima = new LinkedList<>();
        
        if (!previas.containsKey(destino)) {
            return rutaOptima; // Lista vacía si no hay ruta
        }

        Connection conexion = previas.get(destino);
        while (conexion != null) {
            rutaOptima.addFirst(conexion.getRuta());
            conexion = previas.get(conexion.getParada());
        }

        // Agregar información de tiempo estimado (opcional)
        if (!rutaOptima.isEmpty()) {
            double tiempoEstimado = distanciaTotal * 1.5; // Factor de conversión a minutos
            rutaOptima.getFirst().setTiempoEstimado(tiempoEstimado);
        }
        
        return rutaOptima;
    }

    // Clase interna mejorada
    private static class Connection {
        private final Parada parada;
        private final Ruta ruta;
        private final double peso;

        public Connection(Parada parada, Ruta ruta, double peso) {
            this.parada = Objects.requireNonNull(parada);
            this.ruta = Objects.requireNonNull(ruta);
            this.peso = peso;
        }

        public Parada getParada() { return parada; }
        public Ruta getRuta() { return ruta; }
        public double getPeso() { return peso; }

        @Override
        public String toString() {
            return String.format("A %s (%.2f km)", parada.getNombre(), peso);
        }
    }

    // Método para diagnóstico
    public void imprimirGrafo() {
        System.out.println("=== Estructura del Grafo ===");
        graph.forEach((parada, conexiones) -> {
            System.out.printf("\nParada: %s (%s)\n", parada.getNombre(), parada.getTipo());
            conexiones.forEach(c -> System.out.printf("  -> %s\n", c));
        });
    }
}