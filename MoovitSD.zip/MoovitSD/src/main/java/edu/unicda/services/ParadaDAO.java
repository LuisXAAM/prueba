package edu.unicda.services;

import edu.unicda.models.Parada;
import edu.unicda.utils.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ParadaDAO {
    public List<Parada> obtenerTodasLasParadas() throws SQLException {
        List<Parada> paradas = new ArrayList<>();
        String sql = "SELECT ParadaID, Nombre, Latitud, Longitud, Tipo FROM Paradas";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Parada parada = new Parada(
                    rs.getInt("ParadaID"),
                    rs.getString("Nombre"),
                    rs.getDouble("Latitud"),
                    rs.getDouble("Longitud")
                );
                parada.setTipo(rs.getString("Tipo"));
                paradas.add(parada);
            }
        }
        return paradas;
    }
    
   public List<Parada> obtenerParadasPorRuta(int rutaId) throws SQLException {
    List<Parada> paradas = new ArrayList<>();
    
    String sql = "SELECT p.ParadaID, p.Nombre, p.Latitud, p.Longitud, p.Tipo " +
                 "FROM Paradas p JOIN RutaParadas rp ON p.ParadaID = rp.ParadaID " +
                 "WHERE rp.RutaID = ? ORDER BY rp.Orden";
    
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setInt(1, rutaId);
        
        try (ResultSet rs = pstmt.executeQuery()) {
            if (!rs.isBeforeFirst()) {
                System.out.println("No se encontraron paradas para RutaID: " + rutaId);
                return paradas; // Retorna lista vacía, no null
            }
            
            while (rs.next()) {
                Parada parada = new Parada(
                    rs.getInt("ParadaID"),
                    rs.getString("Nombre"),
                    rs.getDouble("Latitud"),
                    rs.getDouble("Longitud")
                );
                parada.setTipo(rs.getString("Tipo"));
                paradas.add(parada);
            }
        }
    }
        return paradas;
    }   
}