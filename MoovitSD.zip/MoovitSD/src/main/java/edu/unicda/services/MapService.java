package edu.unicda.services;

import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.OSMTileFactoryInfo;
import org.jxmapviewer.viewer.DefaultTileFactory;
import org.jxmapviewer.viewer.GeoPosition;
import org.jxmapviewer.viewer.TileFactoryInfo;
import edu.unicda.models.Parada;
import edu.unicda.models.Ruta;
import org.jxmapviewer.painter.CompoundPainter;
import org.jxmapviewer.painter.Painter;
import org.jxmapviewer.viewer.Waypoint;
import org.jxmapviewer.viewer.WaypointPainter;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import org.jxmapviewer.viewer.DefaultWaypoint;
import org.jxmapviewer.viewer.WaypointRenderer;

public class MapService {
    private final JXMapViewer mapViewer;
    private final List<Parada> paradas;
    private final List<Ruta> rutas;

    public MapService(JXMapViewer mapViewer, List<Parada> paradas, List<Ruta> rutas) {
        this.mapViewer = mapViewer;
        this.paradas = paradas;
        this.rutas = rutas;
        initializeMap();
    }

    private void initializeMap() {
        // Configurar el tile factory de OpenStreetMap
        TileFactoryInfo info = new OSMTileFactoryInfo();
        DefaultTileFactory tileFactory = new DefaultTileFactory(info);
        mapViewer.setTileFactory(tileFactory);
        
        // Centrar el mapa en Santo Domingo
        GeoPosition santoDomingo = new GeoPosition(18.4861, -69.9312);
        mapViewer.setZoom(12);
        mapViewer.setAddressLocation(santoDomingo);
    }

    public void dibujarParadas() {
        // Crear waypoints para las paradas
        Set<CustomWaypoint> waypoints = paradas.stream()
            .map(p -> new CustomWaypoint(new GeoPosition(p.getLatitud(), p.getLongitud()), p.getNombre()))
            .collect(Collectors.toSet());

        // Configurar el painter para las paradas
        WaypointPainter<CustomWaypoint> waypointPainter = new WaypointPainter<>();
        waypointPainter.setWaypoints(waypoints);
        waypointPainter.setRenderer(new CustomWaypointRenderer());

        mapViewer.setOverlayPainter(waypointPainter);
    }

    public void dibujarRuta(List<Parada> paradasRuta, Color color) {
        List<GeoPosition> track = paradasRuta.stream()
            .map(p -> new GeoPosition(p.getLatitud(), p.getLongitud()))
            .collect(Collectors.toList());

        RoutePainter routePainter = new RoutePainter(track, color);
        mapViewer.setOverlayPainter(routePainter);
    }

    // Clase interna para waypoints personalizados
    private static class CustomWaypoint extends DefaultWaypoint {
        private final String label;

        public CustomWaypoint(GeoPosition coord, String label) {
            super(coord);
            this.label = label;
        }

        public String getLabel() { 
            return label; 
        }
    }

    // Renderer personalizado para waypoints
    private static class CustomWaypointRenderer implements WaypointRenderer {
        @Override
        public void paintWaypoint(Graphics2D g, JXMapViewer map, Object waypoint) {
            if (waypoint instanceof CustomWaypoint) {
                CustomWaypoint cw = (CustomWaypoint) waypoint;
                
                Point2D point = map.getTileFactory().geoToPixel(cw.getPosition(), map.getZoom());
                int x = (int) point.getX();
                int y = (int) point.getY();
                
                g.setColor(Color.RED);
                g.fillOval(x-5, y-5, 10, 10);
                
                g.setColor(Color.BLACK);
                g.drawString(cw.getLabel(), x+10, y+5);
            }
        }
    }

    private static class RoutePainter implements Painter<JXMapViewer> {
        private final List<GeoPosition> track;
        private final Color color;

        public RoutePainter(List<GeoPosition> track, Color color) {
            this.track = track;
            this.color = color;
        }

        @Override
        public void paint(Graphics2D g, JXMapViewer map, int w, int h) {
            g = (Graphics2D) g.create();
            Rectangle rect = map.getViewportBounds();
            g.translate(-rect.x, -rect.y);

            g.setColor(color);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setStroke(new BasicStroke(3));

            for (int i = 0; i < track.size() - 1; i++) {
                GeoPosition gp1 = track.get(i);
                GeoPosition gp2 = track.get(i + 1);

                Point2D pt1 = map.getTileFactory().geoToPixel(gp1, map.getZoom());
                Point2D pt2 = map.getTileFactory().geoToPixel(gp2, map.getZoom());

                g.drawLine((int) pt1.getX(), (int) pt1.getY(), (int) pt2.getX(), (int) pt2.getY());
            }

            g.dispose();
        }
    }
}