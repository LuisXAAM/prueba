// RutaDAO.java
package edu.unicda.services;

import edu.unicda.models.Ruta;
import edu.unicda.utils.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RutaDAO {
    public List<Ruta> obtenerTodasLasRutas() throws SQLException {
        List<Ruta> rutas = new ArrayList<>();
        String sql = "SELECT RutaID, Nombre, Tipo, Operadora FROM Rutas";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Ruta ruta = new Ruta();
                ruta.setId(rs.getInt("RutaID"));
                ruta.setNombre(rs.getString("Nombre"));
                ruta.setTipo(rs.getString("Tipo"));
                ruta.setOperadora(rs.getString("Operadora"));
                rutas.add(ruta);
            }
        }
        return rutas;
    }
    
    // Agregar este método a RutaDAO
public List<Ruta> obtenerRutasPorParada(int paradaId) throws SQLException {
    List<Ruta> rutas = new ArrayList<>();
    String sql = "SELECT r.RutaID, r.Nombre, r.Tipo, r.Operadora " +
                 "FROM Rutas r JOIN RutaParadas rp ON r.RutaID = rp.RutaID " +
                 "WHERE rp.ParadaID = ?";
    
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setInt(1, paradaId);
        try (ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                Ruta ruta = new Ruta(
                    rs.getInt("RutaID"),
                    rs.getString("Nombre"),
                    rs.getString("Tipo")
                );
                ruta.setOperadora(rs.getString("Operadora"));
                rutas.add(ruta);
            }
        }
    }
    return rutas;
}
    
    
    public Ruta obtenerRutaPorId(int id) throws SQLException {
        String sql = "SELECT RutaID, Nombre, Tipo, Operadora, HorarioInicio, HorarioFin, FrecuenciaPromedio FROM Rutas WHERE RutaID = ?";
        Ruta ruta = null;
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    ruta = new Ruta();
                    ruta.setId(rs.getInt("RutaID"));
                    ruta.setNombre(rs.getString("Nombre"));
                    ruta.setTipo(rs.getString("Tipo"));
                    ruta.setOperadora(rs.getString("Operadora"));
                    ruta.setHorarioInicio(rs.getString("HorarioInicio"));
                    ruta.setHorarioFin(rs.getString("HorarioFin"));
                    ruta.setFrecuenciaPromedio(rs.getInt("FrecuenciaPromedio"));
                }
            }
        }
        return ruta;
    }
}