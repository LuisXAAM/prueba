package edu.unicda.services;

import edu.unicda.models.Ruta;
import edu.unicda.utils.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RutaDAO {
    /**
     * Obtiene todas las rutas disponibles en la base de datos
     * @return Lista de rutas
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    public List<Ruta> obtenerTodasLasRutas() throws SQLException {
        List<Ruta> rutas = new ArrayList<>();
        String sql = "SELECT RutaID, Nombre, Tipo, Operadora, HorarioInicio, HorarioFin, FrecuenciaPromedio FROM Rutas";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                rutas.add(mapearRuta(rs));
            }
        }
        return rutas;
    }
    
    /**
     * Obtiene las rutas que pasan por una parada específica
     * @param paradaId ID de la parada
     * @return Lista de rutas que incluyen la parada
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    public List<Ruta> obtenerRutasPorParada(int paradaId) throws SQLException {
        Objects.requireNonNull(paradaId, "El ID de parada no puede ser nulo");
        
        List<Ruta> rutas = new ArrayList<>();
        String sql = "SELECT r.RutaID, r.Nombre, r.Tipo, r.Operadora, r.HorarioInicio, r.HorarioFin, r.FrecuenciaPromedio " +
                     "FROM Rutas r JOIN RutaParadas rp ON r.RutaID = rp.RutaID " +
                     "WHERE rp.ParadaID = ? ORDER BY r.Nombre";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, paradaId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    rutas.add(mapearRuta(rs));
                }
            }
        }
        return rutas;
    }
    
    /**
     * Obtiene una ruta por su ID
     * @param id ID de la ruta a buscar
     * @return Objeto Ruta o null si no se encuentra
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    public Ruta obtenerRutaPorId(int id) throws SQLException {
        String sql = "SELECT RutaID, Nombre, Tipo, Operadora, HorarioInicio, HorarioFin, FrecuenciaPromedio " +
                     "FROM Rutas WHERE RutaID = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapearRuta(rs);
                }
            }
        }
        return null;
    }
    
    /**
     * Método auxiliar para mapear un ResultSet a un objeto Ruta
     * @param rs ResultSet con los datos de la ruta
     * @return Objeto Ruta mapeado
     * @throws SQLException Si ocurre un error al acceder a los datos
     */
    private Ruta mapearRuta(ResultSet rs) throws SQLException {
        Ruta ruta = new Ruta();
        ruta.setId(rs.getInt("RutaID"));
        ruta.setNombre(rs.getString("Nombre"));
        ruta.setTipo(rs.getString("Tipo"));
        ruta.setOperadora(rs.getString("Operadora"));
        
        // Campos opcionales (pueden ser null en la base de datos)
        Time horarioInicio = rs.getTime("HorarioInicio");
        Time horarioFin = rs.getTime("HorarioFin");
        
        ruta.setHorarioInicio(horarioInicio != null ? horarioInicio.toString() : null);
        ruta.setHorarioFin(horarioFin != null ? horarioFin.toString() : null);
        ruta.setFrecuenciaPromedio(rs.getInt("FrecuenciaPromedio"));
        
        return ruta;
    }
    
    /**
     * Obtiene las rutas por tipo (Metro, OMSA, Concho, etc.)
     * @param tipo Tipo de ruta a filtrar
     * @return Lista de rutas del tipo especificado
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    public List<Ruta> obtenerRutasPorTipo(String tipo) throws SQLException {
        Objects.requireNonNull(tipo, "El tipo de ruta no puede ser nulo");
        
        List<Ruta> rutas = new ArrayList<>();
        String sql = "SELECT RutaID, Nombre, Tipo, Operadora FROM Rutas WHERE Tipo = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, tipo);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    rutas.add(mapearRuta(rs));
                }
            }
        }
        return rutas;
    }
    
    /**
     * Busca rutas por nombre (búsqueda parcial)
     * @param nombre Parte del nombre de la ruta a buscar
     * @return Lista de rutas que coinciden con el criterio
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    public List<Ruta> buscarRutasPorNombre(String nombre) throws SQLException {
        Objects.requireNonNull(nombre, "El nombre de búsqueda no puede ser nulo");
        
        List<Ruta> rutas = new ArrayList<>();
        String sql = "SELECT RutaID, Nombre, Tipo, Operadora FROM Rutas WHERE Nombre LIKE ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, "%" + nombre + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    rutas.add(mapearRuta(rs));
                }
            }
        }
        return rutas;
    }
}