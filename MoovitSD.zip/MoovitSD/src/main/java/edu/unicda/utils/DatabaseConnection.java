package edu.unicda.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    static {
        // Configuración esencial para autenticación Windows
        System.setProperty("java.library.path", "C:\\Users\\Luisv\\OneDrive\\Escritorio\\sqljdbc_12.10\\enu\\auth\\x64\\mssql-jdbc_auth-12.10.0.x64.dll");
    }

    // Versión simplificada para autenticación Windows
    private static final String URL = "jdbc:sqlserver://localhost:1433;"
                                   + "databaseName=MoovitSD;"
                                   + "encrypt=true;"
                                   + "trustServerCertificate=true;"
                                   + "integratedSecurity=true;"
                                   + "loginTimeout=5";

    public static Connection getConnection() throws SQLException {
        try {
            // 1. Carga el driver (opcional desde JDBC 4.0 pero recomendado)
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            
            // 2. Establece la conexión
            Connection conn = DriverManager.getConnection(URL);
            System.out.println("✅ Conexión exitosa con autenticación Windows");
            return conn;
            
        } catch (ClassNotFoundException ex) {
            throw new SQLException("Error: Driver JDBC no encontrado. Verifica que:\n"
                + "1. Tienes la dependencia mssql-jdbc en pom.xml\n"
                + "2. Usas la versión correcta del driver", ex);
        } catch (SQLException ex) {
            System.err.println("❌ Error de conexión SQL:");
            System.err.println("URL usada: " + URL);
            System.err.println("Código error: " + ex.getErrorCode());
            System.err.println("Estado SQL: " + ex.getSQLState());
            
            // Manejo especial para errores de autenticación
            if (ex.getMessage().contains("authentication")) {
                System.err.println("\n⚠️ Soluciones posibles:");
                System.err.println("1. Elimina authenticationScheme=NTLM si usas autenticación Windows");
                System.err.println("2. Asegúrate que sqljdbc_auth.dll está en:");
                System.err.println("   - C:\\sqljdbc_auth\\x64\\ (para sistemas 64-bit)");
                System.err.println("   - O en java.library.path");
                System.err.println("3. Verifica permisos de tu usuario Windows en SQL Server");
            }
            throw ex;
        }
    }

    public static void main(String[] args) {
        try {
            Connection conn = getConnection();
            System.out.println("Conectado a: " + conn.getMetaData().getDatabaseProductName());
            conn.close();
        } catch (SQLException ex) {
            System.err.println("Error detallado:");
            ex.printStackTrace();
        }
    }
}