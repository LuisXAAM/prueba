package edu.unicda.views;

import edu.unicda.models.Parada;
import edu.unicda.models.Ruta;
import edu.unicda.services.MapService;
import edu.unicda.services.ParadaDAO;
import edu.unicda.services.RouteFinder;
import edu.unicda.services.RutaDAO;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.OSMTileFactoryInfo;
import org.jxmapviewer.viewer.DefaultTileFactory;
import org.jxmapviewer.viewer.GeoPosition;
import org.jxmapviewer.viewer.TileFactoryInfo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MainFrame extends JFrame {
    // Componentes de la interfaz
    private JTextField origenField;
    private JTextField destinoField;
    private JButton buscarButton;
    private JList<Ruta> rutasList;
    private DefaultListModel<Ruta> listModel;
    
    // Componentes del mapa
    private JXMapViewer mapViewer;
    
    // Servicios
    private RutaDAO rutaDAO;
    private ParadaDAO paradaDAO;
    private MapService mapService;
    private RouteFinder routeFinder;
    
    public MainFrame() {
        setTitle("Moovit SD - Transporte Santo Domingo");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        try {
            // Inicializar DAOs
            rutaDAO = new RutaDAO();
            paradaDAO = new ParadaDAO();
            
            // Obtener datos iniciales
            List<Ruta> rutas = rutaDAO.obtenerTodasLasRutas();
            List<Parada> paradas = paradaDAO.obtenerTodasLasParadas();
            
            // Inicializar servicios
            routeFinder = new RouteFinder(rutas);
            
            initComponents(paradas, rutas);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al inicializar la aplicación: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    private void initComponents(List<Parada> paradas, List<Ruta> rutas) {
        // Configurar el layout principal
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Panel de control lateral
        JPanel controlPanel = new JPanel(new BorderLayout(10, 10));
        controlPanel.setPreferredSize(new Dimension(300, 600));
        
        // Panel de búsqueda
        JPanel searchPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Buscar Ruta"));
        
        origenField = new JTextField();
        destinoField = new JTextField();
        buscarButton = new JButton("Buscar Ruta Óptima");
        
        searchPanel.add(new JLabel("Origen:"));
        searchPanel.add(origenField);
        searchPanel.add(new JLabel("Destino:"));
        searchPanel.add(destinoField);
        searchPanel.add(buscarButton);
        
        // Panel de resultados
        JPanel resultsPanel = new JPanel(new BorderLayout());
        resultsPanel.setBorder(BorderFactory.createTitledBorder("Rutas Encontradas"));
        
        listModel = new DefaultListModel<>();
        rutasList = new JList<>(listModel);
        rutasList.setCellRenderer(new RutaListRenderer());
        
        resultsPanel.add(new JScrollPane(rutasList), BorderLayout.CENTER);
        
        // Configurar el mapa
        mapViewer = new JXMapViewer();
        mapService = new MapService(mapViewer, paradas, rutas);
        mapService.dibujarParadas();
        
        // Configurar acciones
        buscarButton.addActionListener(this::buscarRutas);
        rutasList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && !rutasList.isSelectionEmpty()) {
                Ruta rutaSeleccionada = rutasList.getSelectedValue();
                try {
                    List<Parada> paradasRuta = paradaDAO.obtenerParadasPorRuta(rutaSeleccionada.getId());
                    mapService.dibujarRuta(paradasRuta, Color.BLUE);
                    
                    // Centrar mapa en la primera parada
                    if (!paradasRuta.isEmpty()) {
                        Parada primera = paradasRuta.get(0);
                        mapViewer.setCenterPosition(new GeoPosition(primera.getLatitud(), primera.getLongitud()));
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Error al mostrar la ruta: " + ex.getMessage(),
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        // Ensamblar componentes
        controlPanel.add(searchPanel, BorderLayout.NORTH);
        controlPanel.add(resultsPanel, BorderLayout.CENTER);
        
        mainPanel.add(controlPanel, BorderLayout.WEST);
        mainPanel.add(mapViewer, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private void buscarRutas(ActionEvent evt) {
        String origenText = origenField.getText().trim();
        String destinoText = destinoField.getText().trim();
        
        if (origenText.isEmpty() || destinoText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese origen y destino", 
                    "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            // Buscar paradas que coincidan con el texto (simplificado)
            List<Parada> todasParadas = paradaDAO.obtenerTodasLasParadas();
            Parada origen = encontrarParadaPorNombre(origenText, todasParadas);
            Parada destino = encontrarParadaPorNombre(destinoText, todasParadas);
            
            if (origen == null || destino == null) {
                JOptionPane.showMessageDialog(this, "No se encontraron las paradas especificadas",
                        "Advertencia", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            // Encontrar la mejor ruta
            List<Ruta> rutasOptimas = routeFinder.encontrarMejorRuta(origen, destino);
            
            if (rutasOptimas.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No se encontró una ruta entre las paradas seleccionadas",
                        "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            // Mostrar resultados
            listModel.clear();
            for (Ruta ruta : rutasOptimas) {
                listModel.addElement(ruta);
            }
            
            // Dibujar la ruta en el mapa
            List<Parada> paradasRuta = new ArrayList<>();
            paradasRuta.add(origen);
            
            // Obtener todas las paradas de la ruta óptima
            for (Ruta ruta : rutasOptimas) {
                List<Parada> paradasDeRuta = paradaDAO.obtenerParadasPorRuta(ruta.getId());
                paradasRuta.addAll(paradasDeRuta);
            }
            
            paradasRuta.add(destino);
            mapService.dibujarRuta(paradasRuta, Color.BLUE);
            
            // Centrar el mapa en el punto medio
            double latMedia = (origen.getLatitud() + destino.getLatitud()) / 2;
            double lonMedia = (origen.getLongitud() + destino.getLongitud()) / 2;
            mapViewer.setCenterPosition(new GeoPosition(latMedia, lonMedia));
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al buscar rutas: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
    
    private Parada encontrarParadaPorNombre(String nombre, List<Parada> paradas) {
        // Búsqueda simple (en una app real usarías un algoritmo de búsqueda mejorado)
        for (Parada parada : paradas) {
            if (parada.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                return parada;
            }
        }
        return null;
    }
    
    // Renderer personalizado para la lista de rutas
    private static class RutaListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, 
                boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            if (value instanceof Ruta) {
                Ruta ruta = (Ruta) value;
                setText(String.format("%s (%s) - %s", 
                    ruta.getNombre(), 
                    ruta.getTipo(), 
                    ruta.getOperadora()));
                
                // Color basado en el tipo de ruta
                switch (ruta.getTipo().toLowerCase()) {
                    case "metro":
                        setBackground(new Color(220, 240, 255));
                        break;
                    case "omsa":
                        setBackground(new Color(255, 240, 220));
                        break;
                    case "concho":
                        setBackground(new Color(230, 255, 220));
                        break;
                    default:
                        setBackground(Color.WHITE);
                }
                
                if (isSelected) {
                    setBackground(getBackground().darker());
                }
            }
            
            return this;
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                // Establecer look and feel del sistema
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                
                // Configurar estilo para mejor apariencia
                UIManager.put("ScrollBar.width", 12);
                UIManager.put("List.rendererUseListColors", true);
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }
}