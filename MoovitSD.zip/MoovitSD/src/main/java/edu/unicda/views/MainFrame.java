package edu.unicda.views;

import edu.unicda.models.Parada;
import edu.unicda.models.Ruta;
import edu.unicda.services.MapService;
import edu.unicda.services.ParadaDAO;
import edu.unicda.services.RouteFinder;
import edu.unicda.services.RutaDAO;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.viewer.GeoPosition;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.util.List;
import java.util.Objects;

public class MainFrame extends JFrame {
    private JTextField origenField;
    private JTextField destinoField;
    private JButton buscarButton;
    private JList<Ruta> rutasList;
    private DefaultListModel<Ruta> listModel;
    private JXMapViewer mapViewer;
    
    private  RutaDAO rutaDAO;
    private  ParadaDAO paradaDAO;
    private  RouteFinder routeFinder;
    private MapService mapService;

    public MainFrame() {
        setTitle("Moovit SD - Transporte Santo Domingo");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        try {
            // Inicializar DAOs
            rutaDAO = new RutaDAO();
            paradaDAO = new ParadaDAO();
            
            // Obtener datos iniciales
            List<Ruta> rutas = rutaDAO.obtenerTodasLasRutas();
            List<Parada> paradas = paradaDAO.obtenerTodasLasParadas();
            
            // Inicializar RouteFinder con el DAO
            routeFinder = new RouteFinder(rutas, paradaDAO);
            
            // Configurar interfaz
            initComponents(paradas, rutas);
            
            // Cargar datos iniciales
            cargarDatosIniciales();
            
        } catch (SQLException e) {
            mostrarError("Error al inicializar la aplicación: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        } catch (IllegalArgumentException e) {
            mostrarError("Error en datos: " + e.getMessage());
            System.exit(1);
        }
    }

    private void initComponents(List<Parada> paradas, List<Ruta> rutas) {
        // Configurar layout principal
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel de control lateral
        JPanel controlPanel = new JPanel(new BorderLayout(10, 10));
        controlPanel.setPreferredSize(new Dimension(300, 700));

        // Panel de búsqueda
        JPanel searchPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Buscar Ruta"));

        origenField = new JTextField();
        destinoField = new JTextField();
        buscarButton = new JButton("Buscar Ruta Óptima");

        searchPanel.add(new JLabel("Origen:"));
        searchPanel.add(origenField);
        searchPanel.add(new JLabel("Destino:"));
        searchPanel.add(destinoField);
        searchPanel.add(buscarButton);

        // Panel de resultados
        JPanel resultsPanel = new JPanel(new BorderLayout());
        resultsPanel.setBorder(BorderFactory.createTitledBorder("Rutas Encontradas"));

        listModel = new DefaultListModel<>();
        rutasList = new JList<>(listModel);
        rutasList.setCellRenderer(new RutaListRenderer());

        resultsPanel.add(new JScrollPane(rutasList), BorderLayout.CENTER);

        // Configurar el mapa
        mapViewer = new JXMapViewer();
        mapService = new MapService(mapViewer, paradas, rutas);
        mapService.dibujarParadas();

        // Configurar acciones
        buscarButton.addActionListener(this::buscarRutas);
        rutasList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                mostrarRutaSeleccionada();
            }
        });

        // Ensamblar componentes
        controlPanel.add(searchPanel, BorderLayout.NORTH);
        controlPanel.add(resultsPanel, BorderLayout.CENTER);

        mainPanel.add(controlPanel, BorderLayout.WEST);
        mainPanel.add(mapViewer, BorderLayout.CENTER);

        add(mainPanel);
    }

    private void cargarDatosIniciales() {
        try {
            List<Ruta> rutas = rutaDAO.obtenerTodasLasRutas();
            
            if (rutas.isEmpty()) {
                mostrarAdvertencia("No hay rutas disponibles en la base de datos");
                return;
            }

            // Mostrar primera ruta como ejemplo
            Ruta primeraRuta = rutas.get(0);
            List<Parada> paradasRuta = paradaDAO.obtenerParadasPorRuta(primeraRuta.getId());
            
            if (paradasRuta.isEmpty()) {
                mostrarAdvertencia("La ruta seleccionada no tiene paradas asignadas");
            } else {
                mapService.dibujarRuta(paradasRuta, Color.BLUE);
                centrarMapaEnParada(paradasRuta.get(0));
                
                // Seleccionar la primera ruta en la lista
                listModel.addElement(primeraRuta);
                rutasList.setSelectedIndex(0);
            }
        } catch (SQLException ex) {
            mostrarError("Error al cargar datos iniciales: " + ex.getMessage());
        }
    }

    private void buscarRutas(ActionEvent evt) {
        String origenText = origenField.getText().trim();
        String destinoText = destinoField.getText().trim();

        if (origenText.isEmpty() || destinoText.isEmpty()) {
            mostrarAdvertencia("Por favor ingrese origen y destino");
            return;
        }

        try {
            List<Parada> todasParadas = paradaDAO.obtenerTodasLasParadas();
            Parada origen = encontrarParadaPorNombre(origenText, todasParadas);
            Parada destino = encontrarParadaPorNombre(destinoText, todasParadas);

            if (origen == null || destino == null) {
                mostrarAdvertencia("No se encontraron las paradas especificadas");
                return;
            }

            List<Ruta> rutasOptimas = routeFinder.encontrarMejorRuta(origen, destino);
            actualizarListaRutas(rutasOptimas);

            if (!rutasOptimas.isEmpty()) {
                rutasList.setSelectedIndex(0); // Seleccionar primera ruta automáticamente
            } else {
                mostrarAdvertencia("No se encontró una ruta entre las paradas seleccionadas");
            }
        } catch (SQLException ex) {
            mostrarError("Error al buscar rutas: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void actualizarListaRutas(List<Ruta> rutas) {
        listModel.clear();
        if (rutas != null) {
            rutas.forEach(listModel::addElement);
        }
    }

    private void mostrarRutaSeleccionada() {
        Ruta rutaSeleccionada = rutasList.getSelectedValue();
        if (rutaSeleccionada != null) {
            try {
                List<Parada> paradasRuta = paradaDAO.obtenerParadasPorRuta(rutaSeleccionada.getId());
                
                if (paradasRuta.isEmpty()) {
                    mostrarAdvertencia("Esta ruta no tiene paradas asignadas");
                } else {
                    mapService.dibujarRuta(paradasRuta, Color.BLUE);
                    centrarMapaEnParada(paradasRuta.get(0));
                }
            } catch (SQLException ex) {
                mostrarError("Error al mostrar la ruta: " + ex.getMessage());
            }
        }
    }

    private void centrarMapaEnParada(Parada parada) {
        mapViewer.setCenterPosition(new GeoPosition(parada.getLatitud(), parada.getLongitud()));
        mapViewer.setZoom(15);
    }

    private Parada encontrarParadaPorNombre(String nombre, List<Parada> paradas) {
        return paradas.stream()
                .filter(p -> p.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .findFirst()
                .orElse(null);
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarAdvertencia(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Advertencia", JOptionPane.WARNING_MESSAGE);
    }

    // Renderer personalizado para la lista de rutas
    private static class RutaListRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, 
                                                    boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            if (value instanceof Ruta) {
                Ruta ruta = (Ruta) value;
                setText(String.format("%s (%s)", ruta.getNombre(), ruta.getTipo()));
                
                // Color según tipo de ruta
                Color colorFondo;
                switch (ruta.getTipo().toLowerCase()) {
                    case "metro": colorFondo = new Color(200, 230, 255); break;
                    case "omsa": colorFondo = new Color(255, 230, 200); break;
                    case "concho": colorFondo = new Color(230, 255, 200); break;
                    default: colorFondo = Color.WHITE;
                }
                
                setBackground(isSelected ? colorFondo.darker() : colorFondo);
                setForeground(isSelected ? Color.WHITE : Color.BLACK);
            }
            return this;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                new MainFrame().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, 
                    "Error al iniciar la aplicación: " + e.getMessage(),
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}