/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package edu.unicda.moovitsd;

/**
 *
 * @author Luisv
 */
public class MoovitSD {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
