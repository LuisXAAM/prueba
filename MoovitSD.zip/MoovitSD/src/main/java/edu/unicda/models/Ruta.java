// Ruta.java
package edu.unicda.models;

import java.util.List;

public class Ruta {
    private int id;
    private String nombre;
    private String tipo;
    private String operadora;
    private String horarioInicio;
    private String horarioFin;
    private int frecuenciaPromedio;
 

    // Constructor, getters y setters
    public Ruta() {}
    
    public Ruta(int id, String nombre, String tipo) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getOperadora() {
        return operadora;
    }

    public void setOperadora(String operadora) {
        this.operadora = operadora;
    }

    public String getHorarioInicio() {
        return horarioInicio;
    }

    public void setHorarioInicio(String horarioInicio) {
        this.horarioInicio = horarioInicio;
    }

    public String getHorarioFin() {
        return horarioFin;
    }

    public void setHorarioFin(String horarioFin) {
        this.horarioFin = horarioFin;
    }

    public int getFrecuenciaPromedio() {
        return frecuenciaPromedio;
    }

    public void setFrecuenciaPromedio(int frecuenciaPromedio) {
        this.frecuenciaPromedio = frecuenciaPromedio;
    }

    public void setTiempoEstimado(double tiempoEstimado) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
   
}


